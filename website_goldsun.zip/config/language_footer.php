<?php
return [
    'info_contact_vi'=>[
        'address' =>[
            'title' => 'ĐỊA CHỈ',
            'content'=>'<p><strong>VPGD:</strong> Số nhà 11, Tổ 13 Khu An Lạc, Phường Cầu Diễn, Quận Nam Từ Liêm, Hà Nội<p><strong>Xưởng Sản Xuất:</strong> Km 12, Quốc lộ 32, Phường Phúc Diễn, Q. Bắc Từ Liêm, Tp. Hà Nội</p>'

        ],
        'phone'=>[
            'title'=>'ĐIỆN THOẠI',
            'content'=> '<p class="text-contact">Tel: 024.37.87.20.35 - HotLine: 0904.121.830</p>'
        ]
    ],
    'info_contact_en'=>[
        'address' =>[
            'title' => 'ADDRESS',
            'content'=>'EQUIPMENT CO., MOULD AND CONTROL OF THAI VIETNAM Climate<br>
                Address: Sports Complex My Dinh Nhan My, My Dinh, Tu Liem, Hanoi<br>
                Tel: (84-4) 37854282 Fax: (84-4) 37854283 © 2011<br>
                Copyright by Co. Machinery and supplies Goldsun'
        ],
        'phone'=>[
            'title'=>'PHONE',
            'content'=> '<p class="text-contact">Tel: 024.37.87.20.35 - HotLine: 0904.121.830</p>'
        ]
    ]
]

?>