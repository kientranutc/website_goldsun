<?php

return [
    'category'=>'Danh Mục'
];